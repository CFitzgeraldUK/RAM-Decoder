def image(maker):
  image_dict = {
    
    "CXMT": "https://upload.wikimedia.org/wikipedia/en/thumb/c/cf/CXMT.svg/2560px-CXMT.svg.png",
    "Elpida": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Elpida_Logo.svg/2560px-Elpida_Logo.svg.png",
    "JHICC": "https://cdn.kipost.net/news/photo/old/3716997708_1536060825.4316.png",
    "Micron": "https://upload.wikimedia.org/wikipedia/de/thumb/0/03/Micron_Logo.svg/1200px-Micron_Logo.svg.png",
    "Nanya": "https://aktienfinder.net/assets/d16ff8ad302838d17819cb1740d1b545.webp",
    "PSC": "https://isesglobal.com/wp-content/uploads/2021/01/powerchip.png",
    "Samsung": "https://images.samsung.com/is/image/samsung/assets/global/about-us/brand/logo/mo/360_197_1.png?",
    "SK Hynix": "https://unicorn-nest.com/wp-content/uploads/2021/11/SK-Hynix-scaled.jpg",
  }
  
  image = image_dict[maker]
  return image